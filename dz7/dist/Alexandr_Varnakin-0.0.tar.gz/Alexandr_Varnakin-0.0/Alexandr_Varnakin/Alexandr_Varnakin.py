def greeting():
    print("Hi, my name is Sanek")


def poslat_nahui():
    print("Poshel nahui")


def ya_gay():
    print("Fuck you! You gay!")