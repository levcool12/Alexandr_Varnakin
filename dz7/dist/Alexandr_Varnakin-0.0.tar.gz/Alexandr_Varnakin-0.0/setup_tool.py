from setuptools import setup

setup(name='Alexandr_Varnakin',
      version='0.0',
      description='Coolest man on Earth',
      packages=['Alexandr_Varnakin'],
      author_email='mamadorogayamoskva@gmail.com',
      zip_safe=False)